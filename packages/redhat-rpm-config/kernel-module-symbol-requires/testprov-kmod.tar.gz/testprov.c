#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

#define DRIVER_AUTHOR "Red Hat Kernel General QE"
#define DRIVER_DESC   "KG Symbol Export Test KMOD for 4.18.0-KG"

MODULE_LICENSE("GPL");
MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_VERSION("4.18.0-KG");
MODULE_SUPPORTED_DEVICE("testdevice-provides");


u64 saa7146_vmalloc_build_pgtable(int d)
{
	printk(KERN_ALERT "provided symbol called with argument %d\n", d);

	return ~0x42LLU;
}
EXPORT_SYMBOL(saa7146_vmalloc_build_pgtable);

static int __init init_kgtest_provides(void)
{
        printk(KERN_INFO "Init KG symbol provides test driver for "
			 "4.18.0-KG.\n");
        return 0;
}

static void __exit cleanup_kgtest_provides(void)
{
        printk(KERN_INFO "Cleanup KG symbol provides test driver.\n");
}
module_init(init_kgtest_provides);
module_exit(cleanup_kgtest_provides);
