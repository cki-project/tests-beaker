#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

#define DRIVER_AUTHOR "Red Hat Kernel General QE"
#define DRIVER_DESC   "KG Symbol Usage Test KMOD for 4.18.0-KG"

MODULE_LICENSE("GPL");
MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_VERSION("4.18.0-KG");
MODULE_SUPPORTED_DEVICE("testdevice-requires");


extern u64 saa7146_vmalloc_build_pgtable(int d);

static int __init init_kgtest_requires(void)
{
        printk(KERN_INFO "Init KG symbol requires test driver for "
			 "4.18.0-KG.\n");

	saa7146_vmalloc_build_pgtable(23);

        return 0;
}

static void __exit cleanup_kgtest_requires(void)
{
        printk(KERN_INFO "Cleanup KG symbol requires test driver.\n");
}
module_init(init_kgtest_requires);
module_exit(cleanup_kgtest_requires);
